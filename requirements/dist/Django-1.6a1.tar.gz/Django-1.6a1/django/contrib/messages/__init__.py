from __future__ import absolute_import

from django.contrib.messages.api import *
from django.contrib.messages.constants import *
