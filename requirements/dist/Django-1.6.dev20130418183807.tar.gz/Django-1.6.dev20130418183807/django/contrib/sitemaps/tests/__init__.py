from .test_flatpages import FlatpagesSitemapTests
from .test_generic import GenericViewsSitemapTests
from .test_http import HTTPSitemapTests
from .test_https import HTTPSSitemapTests, HTTPSDetectionSitemapTests
