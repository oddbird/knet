from django.contrib.auth.tests.test_custom_user import *
from django.contrib.auth.tests.test_auth_backends import *
from django.contrib.auth.tests.test_basic import *
from django.contrib.auth.tests.test_context_processors import *
from django.contrib.auth.tests.test_decorators import *
from django.contrib.auth.tests.test_forms import *
from django.contrib.auth.tests.test_remote_user import *
from django.contrib.auth.tests.test_management import *
from django.contrib.auth.tests.test_models import *
from django.contrib.auth.tests.test_handlers import *
from django.contrib.auth.tests.test_hashers import *
from django.contrib.auth.tests.test_signals import *
from django.contrib.auth.tests.test_tokens import *
from django.contrib.auth.tests.test_views import *

# The password for the fixture data users is 'password'
