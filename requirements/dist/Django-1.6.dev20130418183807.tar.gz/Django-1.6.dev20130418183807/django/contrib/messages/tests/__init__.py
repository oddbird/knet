from django.contrib.messages.tests.test_cookie import CookieTest
from django.contrib.messages.tests.test_fallback import FallbackTest
from django.contrib.messages.tests.test_middleware import MiddlewareTest
from django.contrib.messages.tests.test_session import SessionTest
from django.contrib.messages.tests.test_mixins import SuccessMessageMixinTests
