from django.contrib.formtools.tests.tests import *
from django.contrib.formtools.tests.wizard import *
