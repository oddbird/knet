from django.contrib.flatpages.tests.test_csrf import *
from django.contrib.flatpages.tests.test_forms import *
from django.contrib.flatpages.tests.test_models import *
from django.contrib.flatpages.tests.test_middleware import *
from django.contrib.flatpages.tests.test_templatetags import *
from django.contrib.flatpages.tests.test_views import *
