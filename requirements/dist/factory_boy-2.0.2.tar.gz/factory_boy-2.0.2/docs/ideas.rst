Ideas
=====


This is a list of future features that may be incorporated into factory_boy:

* **A 'options' attribute**: instead of adding more class-level constants, use a django-style ``class Meta`` Factory attribute with all options there

