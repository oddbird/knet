OAuth2
======

Simplistic OAuth2 library.
