try:
    from urllib import parse as urlparse
    urlencode = urlparse.urlencode
except ImportError:
    import urlparse
    from urllib import urlencode
