from os.path import join, dirname

from setuptools import setup

here = dirname(__file__)

long_description = (open(join(here, "README.rst")).read() + "\n\n" +
                    open(join(here, "CHANGES.rst")).read() + "\n\n" +
                    open(join(here, "TODO.rst")).read())

def get_version():
    fh = open(join(here, "oauth2", "__init__.py"))
    try:
        for line in fh.readlines():
            if line.startswith("__version__ ="):
                return line.split("=")[1].strip().strip('"\'')
    finally:
        fh.close()

setup(
    name="oauth2lib",
    version=get_version(),
    description="A simplistic OAuth2 library.",
    long_description=long_description,
    author="Carl Meyer",
    author_email="carl@oddbird.net",
    url="https://github.com/carljm/oauth2/",
    packages=['oauth2'],
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Environment :: Web Environment",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: BSD License",
        "Operating System :: OS Independent",
        "Programming Language :: Python",
        "Programming Language :: Python :: 2",
        "Programming Language :: Python :: 2.7",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.2",
        "Programming Language :: Python :: 3.3",
    ],
    zip_safe=False,
    tests_require=[
        "pytest>=2.3.4",
        "pytest-cov",
        "pretend>=0.7",
        "mock>=1.0",
        "WebTest>=2.0",
        ],
    install_requires=[
        "requests",
        ],
    )
