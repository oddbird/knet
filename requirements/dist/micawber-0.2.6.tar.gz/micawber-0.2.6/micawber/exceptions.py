class ProviderException(Exception):
    pass

class ProviderNotFoundException(ProviderException):
    pass
