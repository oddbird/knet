TODO
====

* Split provider classes into Provider and linked Session (so redirect URI and
  state can be per-session rather than per-Provider).
